-- MySQL dump 10.13  Distrib 8.0.36, for Linux (aarch64)
--
-- Host: localhost    Database: BTNS_Dogeparty_Testnet
-- ------------------------------------------------------
-- Server version	8.0.36-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balances`
--

DROP TABLE IF EXISTS `balances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `balances` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `address_id` int unsigned DEFAULT NULL,
  `tick_id` int unsigned DEFAULT NULL,
  `amount` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `address_id` (`address_id`),
  KEY `tick_id` (`tick_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balances`
--

LOCK TABLES `balances` WRITE;
/*!40000 ALTER TABLE `balances` DISABLE KEYS */;
INSERT INTO `balances` VALUES (1,2,1,'1');
/*!40000 ALTER TABLE `balances` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blocks`
--

DROP TABLE IF EXISTS `blocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blocks` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `block_index` int unsigned DEFAULT NULL,
  `block_time` int unsigned DEFAULT NULL,
  `credits_hash_id` int unsigned DEFAULT NULL,
  `debits_hash_id` int unsigned DEFAULT NULL,
  `balances_hash_id` int unsigned DEFAULT NULL,
  `txlist_hash_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `block_index` (`block_index`),
  KEY `credits_hash_id` (`credits_hash_id`),
  KEY `debits_hash_id` (`debits_hash_id`),
  KEY `balances_hash_id` (`balances_hash_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blocks`
--

LOCK TABLES `blocks` WRITE;
/*!40000 ALTER TABLE `blocks` DISABLE KEYS */;
INSERT INTO `blocks` VALUES (1,5940447,1706834334,3,4,5,6),(2,5940448,1706834349,3,4,5,6),(3,5940449,1706834356,3,4,5,6),(4,5940450,1706834373,3,4,5,6),(5,5940451,1706834399,3,4,5,6),(6,5940452,1706834464,3,4,5,6),(7,5940453,1706834476,3,4,5,6),(8,5940454,1706834560,3,4,5,6);
/*!40000 ALTER TABLE `blocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `credits`
--

DROP TABLE IF EXISTS `credits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `credits` (
  `block_index` int unsigned DEFAULT NULL,
  `address_id` int unsigned DEFAULT NULL,
  `tick_id` int unsigned DEFAULT NULL,
  `amount` varchar(250) DEFAULT NULL,
  `action_id` int unsigned DEFAULT NULL,
  `event_id` int unsigned DEFAULT NULL,
  KEY `block_index` (`block_index`),
  KEY `address_id` (`address_id`),
  KEY `action_id` (`action_id`),
  KEY `tick_id` (`tick_id`),
  KEY `event_id` (`event_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `credits`
--

LOCK TABLES `credits` WRITE;
/*!40000 ALTER TABLE `credits` DISABLE KEYS */;
INSERT INTO `credits` VALUES (5940447,2,1,'1',1,2);
/*!40000 ALTER TABLE `credits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `debits`
--

DROP TABLE IF EXISTS `debits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `debits` (
  `block_index` int unsigned DEFAULT NULL,
  `address_id` int unsigned DEFAULT NULL,
  `tick_id` int unsigned DEFAULT NULL,
  `amount` varchar(250) DEFAULT NULL,
  `action_id` int unsigned DEFAULT NULL,
  `event_id` int unsigned DEFAULT NULL,
  KEY `block_index` (`block_index`),
  KEY `address_id` (`address_id`),
  KEY `action_id` (`action_id`),
  KEY `tick_id` (`tick_id`),
  KEY `event_id` (`event_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `debits`
--

LOCK TABLES `debits` WRITE;
/*!40000 ALTER TABLE `debits` DISABLE KEYS */;
/*!40000 ALTER TABLE `debits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `destroys`
--

DROP TABLE IF EXISTS `destroys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `destroys` (
  `tx_index` int unsigned DEFAULT NULL,
  `tick_id` int unsigned DEFAULT NULL,
  `amount` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `source_id` int unsigned DEFAULT NULL,
  `tx_hash_id` int unsigned DEFAULT NULL,
  `block_index` int unsigned DEFAULT NULL,
  `memo_id` int unsigned DEFAULT NULL,
  `status_id` int unsigned DEFAULT NULL,
  KEY `tx_index` (`tx_index`),
  KEY `tick_id` (`tick_id`),
  KEY `source_id` (`source_id`),
  KEY `tx_hash_id` (`tx_hash_id`),
  KEY `block_index` (`block_index`),
  KEY `memo_id` (`memo_id`),
  KEY `status_id` (`status_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `destroys`
--

LOCK TABLES `destroys` WRITE;
/*!40000 ALTER TABLE `destroys` DISABLE KEYS */;
/*!40000 ALTER TABLE `destroys` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_actions`
--

DROP TABLE IF EXISTS `index_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_actions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `action` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `action` (`action`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_actions`
--

LOCK TABLES `index_actions` WRITE;
/*!40000 ALTER TABLE `index_actions` DISABLE KEYS */;
INSERT INTO `index_actions` VALUES (1,'ISSUE');
/*!40000 ALTER TABLE `index_actions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_addresses`
--

DROP TABLE IF EXISTS `index_addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_addresses` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `address` varchar(120) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `address` (`address`(10))
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_addresses`
--

LOCK TABLES `index_addresses` WRITE;
/*!40000 ALTER TABLE `index_addresses` DISABLE KEYS */;
INSERT INTO `index_addresses` VALUES (1,''),(2,'niV5qKrqwsJyhR7SVrPnpuz2TC3aDKTWgU');
/*!40000 ALTER TABLE `index_addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_memos`
--

DROP TABLE IF EXISTS `index_memos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_memos` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `memo` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `memo` (`memo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_memos`
--

LOCK TABLES `index_memos` WRITE;
/*!40000 ALTER TABLE `index_memos` DISABLE KEYS */;
/*!40000 ALTER TABLE `index_memos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_statuses`
--

DROP TABLE IF EXISTS `index_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_statuses` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_statuses`
--

LOCK TABLES `index_statuses` WRITE;
/*!40000 ALTER TABLE `index_statuses` DISABLE KEYS */;
INSERT INTO `index_statuses` VALUES (1,'valid');
/*!40000 ALTER TABLE `index_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_tickers`
--

DROP TABLE IF EXISTS `index_tickers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_tickers` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `tick` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tick` (`tick`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_tickers`
--

LOCK TABLES `index_tickers` WRITE;
/*!40000 ALTER TABLE `index_tickers` DISABLE KEYS */;
INSERT INTO `index_tickers` VALUES (1,'JDOG');
/*!40000 ALTER TABLE `index_tickers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_transactions`
--

DROP TABLE IF EXISTS `index_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_transactions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `hash` varchar(250) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `hash` (`hash`(20))
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_transactions`
--

LOCK TABLES `index_transactions` WRITE;
/*!40000 ALTER TABLE `index_transactions` DISABLE KEYS */;
INSERT INTO `index_transactions` VALUES (1,''),(2,'2bd312cb650617676b0e76def8b9c1ca4db9c6b4ad3b152bdfb87232fa631d07'),(3,'2067c54df15400ce71cf517799e3bc92245c6d22cade6c27ea1cbf7e9d4a883d'),(4,'4f53cda18c2baa0c0354bb5f9a3ecbe5ed12ab4d8e11ba873c2f11161202b945'),(5,'065a7f3f84a659927d02c55d108355fb82d07332cab54455a0a14c17b4016f86'),(6,'1f8e76465bde8973770ba30678d5aad88db5ed85e75cf4cf2747e963182e6afb');
/*!40000 ALTER TABLE `index_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `index_tx_types`
--

DROP TABLE IF EXISTS `index_tx_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `index_tx_types` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(100) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `index_tx_types`
--

LOCK TABLES `index_tx_types` WRITE;
/*!40000 ALTER TABLE `index_tx_types` DISABLE KEYS */;
INSERT INTO `index_tx_types` VALUES (1,'ISSUE');
/*!40000 ALTER TABLE `index_tx_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `issues`
--

DROP TABLE IF EXISTS `issues`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `issues` (
  `tx_index` int unsigned NOT NULL,
  `tick_id` int unsigned DEFAULT NULL,
  `max_supply` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `max_mint` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `decimals` int unsigned DEFAULT NULL,
  `description` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `mint_supply` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `transfer_id` int unsigned DEFAULT NULL,
  `transfer_supply_id` int unsigned DEFAULT NULL,
  `lock_supply` tinyint(1) NOT NULL DEFAULT '0',
  `lock_mint` tinyint(1) NOT NULL DEFAULT '0',
  `lock_description` tinyint(1) NOT NULL DEFAULT '0',
  `lock_rug` tinyint(1) NOT NULL DEFAULT '0',
  `lock_sleep` tinyint(1) NOT NULL DEFAULT '0',
  `lock_callback` tinyint(1) NOT NULL DEFAULT '0',
  `callback_block` int unsigned DEFAULT NULL,
  `callback_tick_id` int unsigned DEFAULT NULL,
  `callback_amount` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `allow_list_id` int unsigned NOT NULL DEFAULT '0',
  `block_list_id` int unsigned NOT NULL DEFAULT '0',
  `source_id` int unsigned DEFAULT NULL,
  `tx_hash_id` int unsigned DEFAULT NULL,
  `block_index` int unsigned DEFAULT NULL,
  `status_id` int unsigned DEFAULT NULL,
  UNIQUE KEY `tx_index` (`tx_index`),
  KEY `tick_id` (`tick_id`),
  KEY `source_id` (`source_id`),
  KEY `transfer_id` (`transfer_id`),
  KEY `transfer_supply_id` (`transfer_supply_id`),
  KEY `status_id` (`status_id`),
  KEY `tx_hash_id` (`tx_hash_id`),
  KEY `callback_tick_id` (`callback_tick_id`),
  KEY `allow_list_id` (`allow_list_id`),
  KEY `block_list_id` (`block_list_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `issues`
--

LOCK TABLES `issues` WRITE;
/*!40000 ALTER TABLE `issues` DISABLE KEYS */;
INSERT INTO `issues` VALUES (1,1,'1','0',0,'http://j-dog.net/images/JDOG_icon.png','1',0,0,1,0,0,0,0,0,0,0,'0',0,0,2,2,5940447,1);
/*!40000 ALTER TABLE `issues` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `list_edits`
--

DROP TABLE IF EXISTS `list_edits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `list_edits` (
  `list_id` int unsigned NOT NULL,
  `item_id` int unsigned DEFAULT NULL,
  `status_id` int unsigned DEFAULT NULL,
  KEY `list_id` (`list_id`),
  KEY `item_id` (`item_id`),
  KEY `status_id` (`status_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `list_edits`
--

LOCK TABLES `list_edits` WRITE;
/*!40000 ALTER TABLE `list_edits` DISABLE KEYS */;
/*!40000 ALTER TABLE `list_edits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `list_items`
--

DROP TABLE IF EXISTS `list_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `list_items` (
  `list_id` int unsigned NOT NULL,
  `item_id` int unsigned DEFAULT NULL,
  KEY `list_id` (`list_id`),
  KEY `item_id` (`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `list_items`
--

LOCK TABLES `list_items` WRITE;
/*!40000 ALTER TABLE `list_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `list_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lists`
--

DROP TABLE IF EXISTS `lists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lists` (
  `tx_index` int unsigned NOT NULL,
  `type` varchar(1) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `edit` varchar(1) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `source_id` int unsigned DEFAULT NULL,
  `list_tx_hash_id` int unsigned DEFAULT NULL,
  `tx_hash_id` int unsigned DEFAULT NULL,
  `block_index` int unsigned DEFAULT NULL,
  `status_id` int unsigned DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lists`
--

LOCK TABLES `lists` WRITE;
/*!40000 ALTER TABLE `lists` DISABLE KEYS */;
/*!40000 ALTER TABLE `lists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mints`
--

DROP TABLE IF EXISTS `mints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mints` (
  `tx_index` int unsigned DEFAULT NULL,
  `tick_id` int unsigned DEFAULT NULL,
  `amount` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `source_id` int unsigned DEFAULT NULL,
  `destination_id` int unsigned DEFAULT NULL,
  `tx_hash_id` int unsigned DEFAULT NULL,
  `block_index` int unsigned DEFAULT NULL,
  `status_id` int unsigned DEFAULT NULL,
  UNIQUE KEY `tx_index` (`tx_index`),
  KEY `tick_id` (`tick_id`),
  KEY `tx_hash_id` (`tx_hash_id`),
  KEY `source_id` (`source_id`),
  KEY `destination_id` (`destination_id`),
  KEY `status_id` (`status_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mints`
--

LOCK TABLES `mints` WRITE;
/*!40000 ALTER TABLE `mints` DISABLE KEYS */;
/*!40000 ALTER TABLE `mints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sends`
--

DROP TABLE IF EXISTS `sends`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sends` (
  `tx_index` int unsigned DEFAULT NULL,
  `tx_hash_id` int unsigned DEFAULT NULL,
  `block_index` int unsigned DEFAULT NULL,
  `tick_id` int unsigned DEFAULT NULL,
  `source_id` int unsigned DEFAULT NULL,
  `destination_id` int unsigned DEFAULT NULL,
  `amount` varchar(250) COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `memo_id` int unsigned DEFAULT NULL,
  `status_id` int unsigned DEFAULT NULL,
  KEY `tx_index` (`tx_index`),
  KEY `tick_id` (`tick_id`),
  KEY `tx_hash_id` (`tx_hash_id`),
  KEY `source_id` (`source_id`),
  KEY `destination_id` (`destination_id`),
  KEY `block_index` (`block_index`),
  KEY `status_id` (`status_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sends`
--

LOCK TABLES `sends` WRITE;
/*!40000 ALTER TABLE `sends` DISABLE KEYS */;
/*!40000 ALTER TABLE `sends` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `tick_id` int unsigned DEFAULT NULL,
  `block_index` int unsigned DEFAULT NULL,
  `supply` varchar(250) DEFAULT NULL,
  `max_supply` varchar(250) DEFAULT NULL,
  `max_mint` varchar(250) DEFAULT NULL,
  `decimals` tinyint DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `lock_supply` tinyint(1) NOT NULL DEFAULT '0',
  `lock_mint` tinyint(1) NOT NULL DEFAULT '0',
  `lock_description` tinyint(1) NOT NULL DEFAULT '0',
  `lock_rug` tinyint(1) NOT NULL DEFAULT '0',
  `lock_sleep` tinyint(1) NOT NULL DEFAULT '0',
  `lock_callback` tinyint(1) NOT NULL DEFAULT '0',
  `callback_block` int unsigned DEFAULT NULL,
  `callback_tick_id` int unsigned DEFAULT NULL,
  `callback_amount` bigint unsigned DEFAULT NULL,
  `allow_list_id` int unsigned NOT NULL DEFAULT '0',
  `block_list_id` int unsigned NOT NULL DEFAULT '0',
  `owner_id` int unsigned DEFAULT NULL,
  `btc_price` varchar(250) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `tick_id` (`tick_id`),
  KEY `owner_id` (`owner_id`),
  KEY `lock_supply` (`lock_supply`),
  KEY `lock_mint` (`lock_mint`),
  KEY `lock_description` (`lock_description`),
  KEY `lock_rug` (`lock_rug`),
  KEY `lock_sleep` (`lock_sleep`),
  KEY `lock_callback` (`lock_callback`),
  KEY `callback_tick_id` (`callback_tick_id`),
  KEY `allow_list_id` (`allow_list_id`),
  KEY `block_list_id` (`block_list_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
INSERT INTO `tokens` VALUES (1,1,5940447,'1','1','0',0,'http://j-dog.net/images/JDOG_icon.png',1,0,0,0,0,0,0,0,0,0,0,2,'0');
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transactions` (
  `tx_index` int unsigned NOT NULL,
  `block_index` int DEFAULT NULL,
  `tx_hash_id` int unsigned NOT NULL,
  `type_id` int unsigned NOT NULL,
  UNIQUE KEY `tx_index` (`tx_index`),
  KEY `block_index` (`block_index`),
  KEY `tx_hash_id` (`tx_hash_id`),
  KEY `type_id` (`type_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,5940447,2,1);
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-01 16:48:17
